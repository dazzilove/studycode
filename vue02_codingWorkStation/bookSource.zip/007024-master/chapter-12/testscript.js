"test": "cross-env NODE_ENV=test mocha-webpack --webpack-config build/webpack.base.conf.js --require test/setup.js test/**/*.spec.js" 
