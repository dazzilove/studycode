…
        dontSendGift: '선물로 보내기 않기'
      },
      madeOrder: false
…
  methods: {
    submitForm() {
      this.madeOrder = true;
    }
  }
…
