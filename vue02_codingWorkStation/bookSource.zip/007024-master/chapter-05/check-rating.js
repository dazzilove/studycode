
methods: {
  checkRating(n, myProduct) {	
    return myProduct.rating - n >= 0;
},
