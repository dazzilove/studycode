business: '직장 주소',
 home: '자택 주소',
 gift: '선물로 보내기',
 sendGift: '선물로 보내기',
 dontSendGift: '선물로 보내기 않기'
},
products: [],
