methods: {
  checkRating(n) {
    return this.product.rating - n >= 0;
  },
