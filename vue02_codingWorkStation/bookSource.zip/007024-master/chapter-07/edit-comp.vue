<template>
  <div>
    <h1> 상품 정보 수정</h1>
  </div>
</template>
<script>
    export default {
		//future
    }
</script>
