order: {
  firstName: '',
  lastName: '',
  address: '',
  city: '',
  zip: '',
  state: '',
  method: '자택',
  gift: '선물로 보내기',
  sendGift: '선물로 보내기',
  dontSendGift: '선물로 보내기 않기'
},
