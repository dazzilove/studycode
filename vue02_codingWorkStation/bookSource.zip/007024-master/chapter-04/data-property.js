data: {
  sitename: 'Vue.js 애완용품샵',
  showProduct: true,
  order: {
    firstName: '',
    lastName: ''
  },
