methods: {
  submitForm() {
    alert('제출 완료');
…
  }
},
