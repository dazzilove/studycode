order: {
  firstName: '',
  lastName: '',
  address: '',
  city: '',
  zip: '',
  state: '',
  method: '자택',
  business: '직장 주소',
  home: '자택 주소',
  gift:'',
  sendGift: '선물로 보내기',
  dontSendGift: '선물로 보내지 않기'
},
