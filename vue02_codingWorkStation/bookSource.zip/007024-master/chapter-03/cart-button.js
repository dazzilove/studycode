data: {
  showProduct: true,
...
},
methods: {
...
  showCheckout() {
       this.showProduct = this.showProduct ? false : true;
   },
}
