computed: {
  cartItemCount: function() {
    return this.cart.length || '';
  }
},
