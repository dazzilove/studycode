methods: {
  addToCart: function() {
    this.cart.push(this.product.id);
  }
}
